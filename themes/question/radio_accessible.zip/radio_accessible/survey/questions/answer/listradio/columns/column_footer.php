<?php
/**
 * Multiple Choice Html : close column containing item row
 * This view is used only if user set more than one column in the question attribute.
 *
 */
 ?>
</ul>
