"use strict";
var IMAGESELECT = function(options){
    var baseSettings = {

    };
    return {};
};
